<?php /* Template Name:Explanations and Definitions */ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
			<h1> Explanations And Definitions </h1>
				

				
				
			<div class='test'>
  <div style='float:left;'>
    <li><a href="#Glossary">Glossary</a></li>
	 <li><a href="#What is a Will? ">What is a Will? </a></li>
	  <li><a href="#After the Will">After the Will</a></li>
	   <li><a href="#Intestacy">Intestacy</a></li>
	    <li><a href="#Inheritance Tax ">Inheritance Tax </a></li>
		 <li><a href="#Probate">Probate</a></li>
		  <li><a href="#Lasting Power of Attorney ">Lasting Power of Attorney</a></li>
		   <li><a href="#Trust Types">Trust Types</a></li>
		    <li><a href="#Family Provision ">Family Provision </a></li>
			 <li><a href="#Parental Responsibility">Parental Responsibility</a></li>
			  <li><a href="#Care Home Fees ">Care Home Fees </a></li>
  </div>
</div>	
		   
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<br /><br />

   
  </div>
</div>
  
  <br /><br />

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
     
     <li><a href="#">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>
  
  
 

<?php get_footer(); ?>