<?php /* Template Name:Private Document Storage*/ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
		   	   <h1> Private Document Storage </h1>
				  <p>Having taken the time and trouble to put your Estate Planning in place, you need to give some thought to where the ORIGINAL documents are going to be kept.</P>	
					 <p>The documents in question are made of paper. That’s obvious, but very relevant to the fact that paper is easily damaged. Water damage, fire damage or even the grandchildren using your Will as a colouring book are not uncommon! What’s more, a Will that looks like it may have been tampered with or had something removed can stop or delay its acceptance at the Probate Court.</p>
						<p>One of the most common problems is the simple loss of your documents. Even when stored at banks and solicitors, people often find that they have great difficulty retrieving them. This difficulty increases when your family try to gain access at the time that they are needed.</p> 
							<p> Finally, if there is anything contentious in your documents, then you certainly don’t want the wrong people getting their hands on them! For example, you have three children, Joe, Mary and Ian. You have not seen Ian for 15 years and are not leaving him anything in your Will. If Ian happens to be the one that finds the Will when you are gone, he could easily “lose” the Will, and he suddenly stands to inherit!.</p>
								<p> In short, the right people need to find the right documents, in the right condition, and at the right time. TWP has a super-secure facility that ensures your documents are available when they are needed..</p>
		  
		   
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<br /><br />


<ul class="nav nav-tabs">
    
    <li><a data-toggle="tab" href="#menu1">Which Documents? </a></li>
    <li><a data-toggle="tab" href="#menu2">What About Digital Records?</a></li>
	<li><a data-toggle="tab" href="#menu3">FAQs</a></li>
  </ul>

  <div class="tab-content">
    <div id="menu1" class="tab-pane fade">
      <h3>Which Document &#8595;</h3>
		<p>Here is a list of the usual documents that you might want to consider storing securely:</p>
		<ul>
			<li>Last Will and Testament</li>
			<li>Family Trust and accompanying documents</li>
			<li>Lasting Power of Attorney</li>
			<li>Property Deeds</li>
			<li>Advance Directives (Living Wills)</li>
			<li>Funeral Plan documents</li>
			<li>Letters of Wishes or additional information </li>
			<li>Helpful information for family members</li>
			<li>Polices and financial paperwork</li>
			</ul>
			
	</div>
    <div id="menu2" class="tab-pane fade">
      <h3>What About Digital Records? &#8595;</h3>
      <p> Increasingly in today’s society, there are digital records and files such as family photos, family trees, online bank statements, passwords and usernames, online accounts such as with Amazon, Paypal, Ebay and Facebook and a host of other records that you may want the family to have access to when you have gone.</p> 
		<p>The Willwriting Partnership has access to a highly-secure digital solution to fulfil this need. The facility is so secure, that the provider also has a set-up for the Royal Household using the same system! </p> 
         <p> -Click here for even more information on Storage- </p>
	</div>
    <div id="menu3" class="tab-pane fade">
      <h3>FAQs &#8595;</h3>
    
	</div>
   
  </div>
</div>
  
  <br /><br />

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
     
     <li><a href="#">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>
  
  
 

<?php get_footer(); ?>