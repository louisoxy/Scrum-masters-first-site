<?php /* Template Name:funeralplan */ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
			<h1> Funeral Plan </h1>
				<p>Thinking about your funeral is a pretty morbid thing to do. It's not the way most people would plan to spend their evening! However, it is often a subject that often sits at the back of your mind. Rather than having it periodically pester your thoughts, why not get your funeral planned, paid for and out of the way so that you can put your attention on the things that are more important to you?</p>
					<p>Not only can you save your family a lot of money, you can take away a great deal of the emotional stress and strain at that sensitive and traumatic time to allow them the opportunity to grieve without having financial strain and upset.</p>
						<p>There are many providers of funeral plans, and TWP aim to find you the plan that best suits your needs. As part of your Estate Planning, we can help you look at the various options that exist and will match those options with the right provider.</p>
							<p>Most funeral planning companies offer some form of guarantee that the funeral director’s costs will be covered at the time that you pass away. Other companies offer a “first death” service for married couples. The point is that your plan will be exactly that – YOUR plan.</p>
		   
		   
		   
		   
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<br /><br />


<ul class="nav nav-tabs">
    
    <li><a data-toggle="tab" href="#menu1">Imagine This </a></li>
    <li><a data-toggle="tab" href="#menu2">ECO Plans</a></li>
    <li><a data-toggle="tab" href="#menu3">FAQs</a></li>
  </ul>

  <div class="tab-content">
    <div id="menu1" class="tab-pane fade">
      <h3>Imagine This &#8595;</h3>
      <p>You have just passed away and your family is speaking with the funeral director. Through the tears of grief, they look through the brochure that the FD is showing them and are confronted with the question “Would you like to go with just a standard coffin or would you prefer to upgrade dad’s send-off with a Hand Crafted Superior Oak Veneered Coffin? It has a three-tiered lid with … etc. Do you think that they are in the right frame of mind to be making such emotionally-charged questions? Is that actually how you want your money to be spent?</p>
 
<p> This is not to put down the value of a superior coffin if that would be your choice. However, the children or surviving family do not know what your choice would have been, and are going to make their choices based on emotion rather than logic. Whilst alive, you can make those decisions and take the strain away from your family.
</p>
    </div>
    <div id="menu2" class="tab-pane fade">
      <h3>ECO Plans &#8595;</h3>
      <p>It is becoming rather popular for people to say “just put me in a cardboard coffin and have done with it!” – either for the sake of simplicity and economy, or for the purpose of being environmentally friendly. If this is how you think, then it is even more important for you to take action about it now, rather than leaving it down to your family.</p>
 
<p>There are plan providers that allow you to specify and pre-pay for a genuinely eco-friendly funeral. For example, the entire carbon-footprint of a funeral service can be offset by tree planting in conservation areas or donating funds to preserve endangered rainforests.</p>
 
<p>Your coffin can be guaranteed to be fair-trade produced from bamboo, willow, wool, cardboard, pine or other ecologically friendly and sustainable materials.</p>
 
<p>If you really want to ensure that your legacy is in harmony with nature, you should make sure that you take the matter into your own hands, rather than leaving it to the family.</p>
 
<p align="center">- Click here for even more information on Funeral Plans -
</p>
    </div>
    <div id="menu3" class="tab-pane fade">
      <h3>FAQs</h3>
      <p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
    </div>
  </div>
</div>
  
  <br /><br />

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
     
     <li><a href="#">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>
  
  
 

<?php get_footer(); ?>