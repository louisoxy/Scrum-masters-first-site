<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="author" content="">
	<script type="text/javascript" src="script.js"></script>
	<link href="https://fonts.googleapis.com/css?family=Indie+Flower" rel="stylesheet">
	<title>Blog Template for Bootstrap</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>	
	<link href="<?php echo get_bloginfo( 'template_directory' );?>/style.css" rel="stylesheet">
	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<?php wp_head();?>
</head>

	<div class="row">
	<div class="col-md-3">
				<img src="//placehold.it/1624x700" class="img-responsive">
		   </div>
		<div class="col-md-4 col-md-push-6">
			<h4>Customer Log-in/Register</h4>
		<div class="row">
			<div class="col-md-5 ">
				<h3>0161 345 34345</h3>
			</div>
		</div>
		<div class="row">
			<div class="col-md-4 ">
				<h4>Socail Links</h4>
			</div>
		</div>
	</div>
	</div>
		</div>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">WebSiteName</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="will-writing.php">Will writing</a></li>
     
     <li><a href="#">Trust Formation</a></li>
          <li><a href="#">Power of Attorney</a></li>
          <li><a href="#">Funeral Plans</a></li>
		   <li><a href="#">Business Wills</a></li>
          <li><a href="#">Probate</a></li>
          <li><a href="#">Contact us</a></li>
    </ul>
  </div>
</nav>
  
<body>

	
	</div>