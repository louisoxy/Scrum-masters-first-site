<?php /* Template Name:About*/ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
			<h1> About </h2>
				<p>Do you own a business? If not, then you probably don't need to read this part of the website, but if you do then you definitely need to keep going. You have additional responsibilities that non-business-owners do not have. Responsibilities to your clients, your staff and your family for them to realise the maximise the value of your business on death. Furthermore, if you were to lose mental capacity, and yet still remain alive, then the business could face even more complications.</P>					<p>Not only can you save your family a lot of money, you can take away a great deal of the emotional stress and strain at that sensitive and traumatic time to allow them the opportunity to grieve without having financial strain and upset.</p>
					<p>Let’s just be clear about one thing – there is no such thing as a “business Will”. A will is always created for a person, not a business. However, as a business owner, your Will should cater for the additional responsibilities that you have, should the worst happen.</p> 
							<p> Who would take over the running of your business? Who would write cheques? Be able to hire and fire staff? Contact your clients? Manage your on-line banking? Even log in to your website or other on-line facilities in order to continue the smooth operation of the company.</p>
								<p> There are certain clauses that would need to be included in your Will and your Lasting Powers of Attorney in order to cater for these and other important matters. What’s more, the whole subject of planning ahead for that eventuality needs careful guidance from a person that can stand back from the detail and take an objective look at what is needed and wanted.</p>
		   
		  
		   
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<br /><br />


<ul class="nav nav-tabs">
    
    <li><a data-toggle="tab" href="#menu1">Meet the experts </a></li>
    <li><a data-toggle="tab" href="#menu2">Work for us</a></li>
  </ul>

  <div class="tab-content">
    <div id="menu1" class="tab-pane fade">
      <h3>Meet the experts &#8595;</h3>
		<p>The act of looking over your business succession plan is actually quite therapeutic! We often get the feedback when we look into this subject with a business owner, that they find the whole process very satisfying and productive – beyond the purpose of the activity to get the correct business Will and business Lasting Powers of Attorney done.</p>
			<p> When was the last time that you really looked at the long-term plan for your company? That long-term view is a necessary part of this process as well as giving due consideration to what would happen if you were to have a problem in the short-term.</p>
				<p> Looking to the future, creating an “ideal scene” for what you want to happen, and then working back from there with your business succession planning consultant can bring about some unexpected and valuable realisations. Even just the initial consultation can be enlightening.</p>
	</div>
    <div id="menu2" class="tab-pane fade">
      <h3>Work for us&#8595;</h3>
      <p> You might be surprised how much your business is worth. Even if you are a “one-man band” where the business is essentially you, the value of your client bank could be significant. Think about a window-cleaner that has built up a round that gets regular income from regular customers. Those regular customers are a potentially saleable asset.</p> 
			<p>It is the same for many businesses and whilst we are not a business transfer agent, we do often uncover previously unrealised value in the course of exploring a business owner’s estate and business activities. </p> 

	</div>
   
  </div>
</div>
  
  <br /><br />

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
     
     <li><a href="#">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>
  
  
 

<?php get_footer(); ?>