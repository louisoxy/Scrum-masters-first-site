<?php /* Template Name:Explanations and Definitions */ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
			<h1> Explanations And Definitions </h2>
				<p>Do you own a business? If not, then you probably don't need to read this part of the website, but if you do then you definitely need to keep going. You have additional responsibilities that non-business-owners do not have. Responsibilities to your clients, your staff and your family for them to realise the maximise the value of your business on death. Furthermore, if you were to lose mental capacity, and yet still remain alive, then the business could face even more complications.</P>					<p>Not only can you save your family a lot of money, you can take away a great deal of the emotional stress and strain at that sensitive and traumatic time to allow them the opportunity to grieve without having financial strain and upset.</p>
					<p>Let’s just be clear about one thing – there is no such thing as a “business Will”. A will is always created for a person, not a business. However, as a business owner, your Will should cater for the additional responsibilities that you have, should the worst happen.</p> 
							<p> Who would take over the running of your business? Who would write cheques? Be able to hire and fire staff? Contact your clients? Manage your on-line banking? Even log in to your website or other on-line facilities in order to continue the smooth operation of the company.</p>
								<p> There are certain clauses that would need to be included in your Will and your Lasting Powers of Attorney in order to cater for these and other important matters. What’s more, the whole subject of planning ahead for that eventuality needs careful guidance from a person that can stand back from the detail and take an objective look at what is needed and wanted.</p>
	

		   
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<br /><br />

   
  </div>
</div>
  
  <br /><br />

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#"></a></li>
     
     <li><a href="#">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>
  
  
 

<?php get_footer(); ?>