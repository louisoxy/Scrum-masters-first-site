<?php /* Template Name: CustomPageT1 */ ?>
<link href="<?php echo get_bloginfo('template_directory'); ?>/blog.css" rel="stylesheet">
<?php get_header(); ?>

	
<div class="container-fluid">
	   <div class="row">
			<div class="col-md-9">
				<img src="//placehold.it/1624x700" class="img-responsive">
		   </div>
		   <div class="panel-group">
		   <div class="col-md-3">
				<div class="panel panel-primary">
					<div class="panel-heading">Panel with panel-primary class</div>
					<div class="panel-body">Panel Content</div>
				</div>
			</div>
			</DIV>
			 <div class="panel-group">
				<div class="col-md-3">
					<div class="panel panel-primary">
						<div class="panel-heading">Panel with panel-primary class</div>
						<div class="panel-body">Panel Content</div>
					</div>
				</div>
			</DIV>
	   </div>
</div>

<div class="container-fluid">
    
    <ul class="nav navbar-nav">
      <li class="active"><a href="#">Will writing</a></li>
     
     <li><a href="will-writing.php">Private Document Storage</a></li>
          <li><a href="#">News blog</a></li>
          <li><a href="#">About</a></li>
		   <li><a href="#">Explanations and Definitions</a></li>
          <li><a href="#">T&Cs / Privacy / Site plan / Asssociation logos / quick link nav / contact us</a></li>
    </ul>
  </div>

<?php get_footer(); ?>